﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CORE.JsonConfig
{
    public class JsonConstructor
    {
        public string browser { set; get; }
        public string account { set; get; }
        public string password { set; get; }

    }
}

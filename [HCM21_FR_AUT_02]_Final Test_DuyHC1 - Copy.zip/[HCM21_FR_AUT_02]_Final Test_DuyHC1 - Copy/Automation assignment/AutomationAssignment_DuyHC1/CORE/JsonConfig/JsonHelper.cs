﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace CORE.JsonConfig
{
    class JsonHelper
    {
        public JsonConstructor ReadConfigFile(string path)
        {
            JsonConstructor json;
            using (StreamReader file = File.OpenText(path))
            {
                JsonSerializer serializer = new JsonSerializer();
                json = (JsonConstructor)serializer.Deserialize(file, typeof(JsonConstructor));
            }
            return json;
        }
    }
}

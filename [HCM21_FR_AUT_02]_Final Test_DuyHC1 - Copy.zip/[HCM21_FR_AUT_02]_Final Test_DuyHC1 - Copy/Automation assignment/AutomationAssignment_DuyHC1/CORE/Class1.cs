﻿using System;

namespace CORE
{
    public class Class1
    {
    }
}

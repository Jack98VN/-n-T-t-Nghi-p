﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace CORE.Interface
{
    public interface IDrivers
    {
        public IWebDriver StartDriver();
        public object DesiredCapabilities();
        public void CloseDriver();
    }
}

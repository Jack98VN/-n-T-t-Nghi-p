﻿using CORE.Interface;
using CORE.JsonConfig;
using CORE.WebDriver;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace CORE.Core
{
    public class DriverManager
    {
        public IWebDriver CreateDriver()
        {
            JsonHelper jsonHelper = new JsonHelper();
            JsonConstructor JsonConfig = jsonHelper.ReadConfigFile(@"C:\Users\Duy\Desktop\[HCM21_FR_AUT_02]_Final Test_DuyHC1\Automation assignment\AutomationAssignment_DuyHC1\CORE\config.json");
            switch (JsonConfig.browser)
            {
                case "chrome":
                    ChromeDesktop chrome = new ChromeDesktop();
                    return chrome.StartDriver();

                case "firefox":
                    FirefoxDesktop firefox = new FirefoxDesktop();
                    return firefox.StartDriver();

                default:
                    ChromeDesktop chromedefault = new ChromeDesktop();
                    return chromedefault.StartDriver();
            }
        }
    }
}

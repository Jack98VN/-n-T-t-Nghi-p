﻿using CORE.Interface;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;

namespace CORE.WebDriver
{
    class ChromeDesktop : IDrivers
    {
        public void CloseDriver()
        {
            throw new NotImplementedException();
        }

        public object DesiredCapabilities()
        {
            ChromeOptions options = new ChromeOptions();
            //AddArgument
            options.AddArgument("start-maximized");
            options.AddArgument("incognito");
            options.AcceptInsecureCertificates = true;
            return options;
        }

        public IWebDriver StartDriver()
        {
            ChromeOptions options = DesiredCapabilities() as ChromeOptions;
            return new ChromeDriver(options);
        }
    }
}

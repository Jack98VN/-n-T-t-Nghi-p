﻿using CORE.Interface;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Text;

namespace CORE.WebDriver
{
    class FirefoxDesktop : IDrivers
    {
        public void CloseDriver()
        {
            throw new NotImplementedException();
        }

        public object DesiredCapabilities()
        {
            FirefoxOptions options = new FirefoxOptions();
           
            #region option Window Size
           /* options.AddArgument("-width");
            options.AddArgument("1280");
            options.AddArgument("-height");
            options.AddArgument("768");*/
            #endregion

            
            return options;
        }

        public IWebDriver StartDriver()
        {
            FirefoxOptions options = DesiredCapabilities() as FirefoxOptions;
            return new FirefoxDriver(options);
        }
    }
}

﻿using RestSharp.APIPage;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace RestSharp.Test
{
    public class API_Test
    {

        /// <summary>
        /// Verify in the response data: should have total record is 24 and response.status is success and response status is 200
        /// </summary>        
        [Fact(DisplayName = "Get Employees and count")]
        public void Test01()
        {
            // Instance new new API_Page();
            API_Page api = new API_Page();

            //Ceate client
            api.CreateRestClient("http://dummy.restapiexample.com/api/v1/");

            //Create Request
            api.CreateRestRequest("employees", RestSharp.Method.GET);

            //Get Response
            RestResponse response = api.GetResponse();

            //Respone will be parsed into Json
            IEnumerable<API_Model> data = new JsonHelpers().ReadJson(response.Content);

            //Count Record should have total record is 24 and response
            int count = 0;
            foreach (var item in data)
            {
                if (item.id != 0) count++;
            }

            //Validate result should be equal 24
            Assert.Equal(24, count);

            //Status is success and response status is 200
            //int StatusCode = (int)RestResponse.StatusCode;
            Assert.Equal("OK", response.StatusCode.ToString());
        }

        /// <summary>
        /// Verify the response data: should have status is success, response status is 200.
        /// Response.message should be "Successfully! Record has been fetched." and id = "id": 1
        /// </summary>
        [Fact(DisplayName = "response data should have status is success, response status is 200 and id is 1")]
        public void Test02()
        {
            // Instance new new API_Page();
            API_Page api = new API_Page();

            //Create Client
            api.CreateRestClient("https://jsonplaceholder.typicode.com/employee/");

            //Create Request
            RestRequest req = api.CreateRestRequest("1", RestSharp.Method.GET);

            //Add Parameters  to request
            req.AddParameter("id", 1);

            //Get response 
            RestResponse response = api.GetResponse();

            //Loop every object in result array
            IEnumerable<API_Model> data = new JsonHelpers().ReadJson(response.Content);
            
            foreach (var item in data)
            {
                if (item.id == 1)
                {

                    //validate the result id = "id":1
                    Assert.Equal(1, item.id);

                    //status is success and response status is 200                   
                    Assert.Equal("OK", response.StatusCode.ToString());

                    //Assert Status is success
                    Assert.Equal("success",item.status);

                    //Response.message should be "Successfully! Record has been fetched."
                    Assert.Equal("Successfully! Record has been added", item.message);
                }
            }
        }

        /// <summary>
        /// Verify the response data should have response.message should be "Successfully! Record has been added." and "status": "success".
        /// </summary>
        [Fact(DisplayName = "POST method and Verify the response data should have response.message should be...")]
        public void Test03()
        {
            //Instance  new API_Page();
            API_Page api = new API_Page();

            //create client
            api.CreateRestClient("http://dummy.restapiexample.com/api/v1/");

            //Create a request
            RestRequest req = api.CreateRestRequest("create", RestSharp.Method.POST);

            //Add parameter to request
            req.AddParameter("name", "FA-DuyHC1");
            req.AddParameter("salary", "N/A");
            req.AddParameter("age", "23");

            //get response
            RestResponse response = api.GetResponse();

            //Convert Respone to Json 
            Response resData = new JsonHelpers().ReadResponse(response.Content);

            /// <summary>
            /// Verify respone data with requirements such as:
            /// </summary>

            //Status respone 201 :Created
            Assert.Equal("Created", response.StatusCode.ToString());

            //Verify "Successfully! Record has been added following data below:
            Assert.Equal("FA-DuyHC1", resData.name);
            Assert.Equal("N/A", resData.salary);
            Assert.Equal("23", resData.age);
            Assert.Equal("Successfully! Record has been added", resData.message);

        }
    }
   
}








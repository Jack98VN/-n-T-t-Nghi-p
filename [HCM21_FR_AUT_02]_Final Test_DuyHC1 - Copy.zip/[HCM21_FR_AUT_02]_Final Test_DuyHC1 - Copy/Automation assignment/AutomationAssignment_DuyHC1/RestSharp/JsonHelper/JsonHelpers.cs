﻿using Newtonsoft.Json;
using RestSharp.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace RestSharp.JsonHelper
{
    public class JsonHelpers
    {
        public IEnumerable<API_Model> ReadJson(string jsonData)
        {
            return JsonConvert.DeserializeObject<IEnumerable<API_Model>>(jsonData);
        }

        public Response ReadResponse(string jsonData)
        {
            return JsonConvert.DeserializeObject<Response>(jsonData);
        }
    }
}

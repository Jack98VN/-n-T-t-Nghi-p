﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestSharp.Model
{
    class API_Model
    {
        public string status { get; set; }
        public string message { get; set; }
        public Data data { get; set; }
    }

    public class Data
    {
        public int id { get; set; }
        public string employee_name { get; set; }
        public string employee_salary { get; set; }
        public string employee_age { get; set; }
        public string profile_image { get; set; }

    }


    //Create class use to POST method
    public class Response
    {
        //create properties
        public string name { get; set; }
        public string salary { get; set; }
        public int age { get; set; }

    }
}

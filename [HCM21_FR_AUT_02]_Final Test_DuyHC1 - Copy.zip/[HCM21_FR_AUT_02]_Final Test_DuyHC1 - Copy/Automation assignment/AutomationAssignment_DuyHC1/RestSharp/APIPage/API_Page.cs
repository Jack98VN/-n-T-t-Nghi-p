﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestSharp.APIPage
{
    public class API_Page
    {
        RestClient client;
        RestRequest request;

        /// <summary>
        /// Create Client to get URL
        /// <param name="URL"></param>
        /// <returns></returns>
        public RestClient CreateRestClient(string URL)
        {
            this.client = new RestClient(URL);
            return this.client;
        }

        /// <summary>
        /// Create Request to get URL and call method Get/Post
        /// <param name="path"></param>
        /// <param name="method"></param>
        /// <returns></returns>
        public RestRequest CreateRestRequest(string path, Method method)
        {
            this.request = new RestRequest(path, method);
            return this.request;
        }

        /// <summary>
        /// get response from api
        /// </summary>
        /// <returns></returns>
        public RestResponse GetResponse()
        {
            //Excute Respone and return result
            return (RestResponse)this.client.Execute(this.request);
        }
    }
}

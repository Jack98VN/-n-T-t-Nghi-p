using System;
using Xunit;

namespace AutomationAssignment_DuyHC1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}

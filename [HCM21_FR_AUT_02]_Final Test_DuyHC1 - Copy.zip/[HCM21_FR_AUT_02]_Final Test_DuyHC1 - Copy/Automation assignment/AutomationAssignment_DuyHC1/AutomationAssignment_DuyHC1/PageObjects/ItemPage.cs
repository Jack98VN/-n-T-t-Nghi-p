﻿using AutomationAssignment_DuyHC1.Base;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class ItemPage : BasePage
    {
        public ItemPage(IWebDriver driver) : base(driver)
        {

        }

        #region Page Elements
        private IWebElement BtnAddToCart => this.driver.FindElement(By.XPath("//button[@name='add-to-cart-sauce-labs-backpack']"));
        private IWebElement LnkShoppingCart => this.driver.FindElement(By.XPath("//a[@class='shopping_cart_link']"));
        private IWebElement LblDescription => this.driver.FindElement(By.XPath("//div[contains(text(),'A red light')]"));
        
        #endregion


        #region Page Actions
        public CartPage AddItemtoCart()
        {           
            BtnAddToCart.Click();
            Thread.Sleep(1000);                    
            LnkShoppingCart.Click();

            return new CartPage(this.driver);
        }

        public bool IsDescriptionIsDisplayed()
        {
            try
            {
                Thread.Sleep(1000);
                return this.LblDescription.Displayed;
              
            }
            catch
            {
                return false;
                
            }
        }

        #endregion

       
    }
}

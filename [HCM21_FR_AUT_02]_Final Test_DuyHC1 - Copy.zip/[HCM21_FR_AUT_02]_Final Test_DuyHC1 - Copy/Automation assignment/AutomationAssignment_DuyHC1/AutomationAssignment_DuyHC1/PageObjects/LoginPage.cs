﻿using AutomationAssignment_DuyHC1.Base;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class LoginPage: BasePage
    {
        #region Instance LoginPage class inheritance form BasePage
        public LoginPage(IWebDriver driver) : base(driver)
        {

        }
        #endregion


        #region Page Elements
        //private IWebElement TxtUsername => new WebKeyword(this.driver).WaiteementFindingVisible(By.XPath("//input[@name='user-name']"), 10);
        private IWebElement TxtUsername => this.driver.FindElement(By.XPath("//input[@id='user-name']"));
     
        //private IWebElement TxtPassword => new WebKeyword(this.driver).WaiteementFindingVisible(By.XPath("//input[@id='password']"), 10);
        private IWebElement TxtPassword => this.driver.FindElement(By.XPath("//input[@id='password']"));   
        private IWebElement BtnLogin => this.driver.FindElement(By.XPath("//input[@type='submit']"));
        private IWebElement MsgError => this.driver.FindElement(By.XPath(" //h3[@data-test='error']"));

        
        #endregion


        #region Page Actions
        public InventoryPage LoginToSystem(string username, string password)
        {
            
            this.TxtUsername.SendKeys(username);
            Thread.Sleep(2000);
            this.TxtPassword.SendKeys(password);
            Thread.Sleep(2000);

            //WebDriverWait waiter = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            //waiter.Until(BtnLogin => this.BtnLogin);           
            this.BtnLogin.Click();
           
            return new InventoryPage(this.driver);
        }
        public bool IsErrorDisplayed()
        {
            try
            {
                return this.MsgError.Displayed;
            }
            catch
            {
                return false;
            }
        }
        #endregion

    }
}

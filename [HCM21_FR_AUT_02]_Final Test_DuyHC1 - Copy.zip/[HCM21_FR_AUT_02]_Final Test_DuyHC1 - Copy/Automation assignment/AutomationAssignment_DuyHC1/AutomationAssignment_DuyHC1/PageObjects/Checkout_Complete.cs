﻿using AutomationAssignment_DuyHC1.Base;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class Checkout_Complete : BasePage
    {
        public Checkout_Complete(IWebDriver driver) : base(driver)
        {


        }

        #region Page Elements
        private IWebElement LnkItem => this.driver.FindElement(By.XPath("//a[@id='item_4_title_link']"));
        #endregion


        #region Page Actions
        public bool IsOrderCreatedSuccessfully()
        {
            return Equals("https://www.saucedemo.com/checkout-complete.html", driver.Url);
        }
        #endregion
    }
}

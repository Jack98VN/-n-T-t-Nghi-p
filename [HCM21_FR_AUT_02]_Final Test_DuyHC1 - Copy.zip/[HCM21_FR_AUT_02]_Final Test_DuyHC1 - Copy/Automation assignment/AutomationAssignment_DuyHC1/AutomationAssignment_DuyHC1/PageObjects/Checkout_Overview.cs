﻿using AutomationAssignment_DuyHC1.Base;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class Checkout_Overview : BasePage
    {
        public Checkout_Overview(IWebDriver driver) : base(driver)
        {

        }

        #region Page Elements
        private IWebElement BtnFinish => this.driver.FindElement(By.XPath("//button[@name='finish']"));

        private IWebElement BtnCancel => this.driver.FindElement(By.XPath("//button[@id='cancel']"));

        private IWebElement LblDescriptionMatch => this.driver.FindElement(By.XPath("//div[contains(text(),'A red light')]"));

        private IWebElement LblPaymentInformation => this.driver.FindElement(By.XPath("//div[contains(text(),'SauceCard')]"));
        private IWebElement LblShippingInformation => this.driver.FindElement(By.XPath(" //div[contains(text(),'FREE PONY ')]"));
        private IWebElement LblItemtotal => this.driver.FindElement(By.XPath("//div[contains(text(),'Item total: $')]"));
        private IWebElement LblTax => this.driver.FindElement(By.XPath("//div[contains(text(),'Tax')]"));
        private IWebElement LblTotal => this.driver.FindElement(By.XPath("//div[contains(text(),'Total')]"));
        
        #endregion


        #region Page Actions
        public Checkout_Complete FinishOrderItem()
        {
            BtnFinish.Click();
            Thread.Sleep(2000);
            return new Checkout_Complete(this.driver);
        }
        //Verify is LblPaymentInformation Displayed
        #region TC1 , TC02
        public bool IsLblPaymentInformationDisplayed()
        {
            try
            {
                return this.LblPaymentInformation.Displayed;
            }
            catch
            {
                return false;
            }
        }
        public bool IsLblShippingInformationDisplayed()
        {
            try
            {
                return this.LblShippingInformation.Displayed;
            }
            catch
            {
                return false;
            }
        }
        public bool IsLblItemtotalDisplayed()
        {
            try
            {
                return this.LblItemtotal.Displayed;
            }
            catch
            {
                return false;
            }
        }
        public bool IsLblTaxDisplayed()
        {
            try
            {
                return this.LblTax.Displayed;
            }
            catch
            {
                return false;
            }
        }
        public bool IsLblTotalDisplayed()
        {
            try
            {
                return this.LblTotal.Displayed;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        //TC03 
        public bool IsButtonCancelDisplayed()
        {
            try
            {
                return this.BtnCancel.Displayed;
            }
            catch
            {
                return false;
            }
        }
        public bool IsButtonFinishDisplayed()
        {
            try
            {
                return this.BtnFinish.Displayed;
            }
            catch
            {
                return false;
            }
        }
      public bool IsDescriptionIsDisplayedAgain()
        {
            try
            {
                return this.LblDescriptionMatch.Displayed;
            }
            catch
            {
                return false;
            }
        }
        #endregion
    }
}

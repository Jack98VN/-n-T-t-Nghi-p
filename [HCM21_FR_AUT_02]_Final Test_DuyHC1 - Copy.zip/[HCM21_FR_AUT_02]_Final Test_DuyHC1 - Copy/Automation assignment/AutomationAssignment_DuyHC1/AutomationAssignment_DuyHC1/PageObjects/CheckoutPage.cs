﻿using AutomationAssignment_DuyHC1.Base;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class CheckoutPage : BasePage
    {
        public CheckoutPage(IWebDriver driver) : base(driver)
        {

        }

        #region Page Elements          
        private IWebElement TxtFirstName => this.driver.FindElement(By.XPath("//input[@id='first-name']"));
        private IWebElement TxtLastName => this.driver.FindElement(By.XPath("//input[@id='last-name']"));
        private IWebElement TxtZip_PostalCode => this.driver.FindElement(By.XPath("//input[@id='postal-code']"));
        private IWebElement BtnContinue => this.driver.FindElement(By.XPath("//input[@id='continue']"));
        
        #endregion


        #region Page Actions
        public Checkout_Overview ConfirmOrderItem(string firstname,string lastname,string zipcode)
        {
            TxtFirstName.SendKeys(firstname);
            Thread.Sleep(1000);

            TxtLastName.SendKeys(lastname);
            Thread.Sleep(1000);

            TxtZip_PostalCode.SendKeys(zipcode);
            Thread.Sleep(1000);

            BtnContinue.Click();
            Thread.Sleep(1000);

            return new Checkout_Overview(this.driver);
        }              
        #endregion
    }
}

﻿    using AutomationAssignment_DuyHC1.Base;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class InventoryPage : BasePage
    {
        #region Instance InventoryPage class inheritance form BasePage
        public InventoryPage(IWebDriver driver) : base(driver)
        {

        }


        #endregion

        #region Page Elements
        //private IWebElement LnkItem => this.driver.FindElement(By.XPath("//a[@id='item_4_title_link']"));
        private IWebElement LnkItem => this.driver.FindElement(By.XPath("//img[@alt='Sauce Labs Backpack']"));
        
        private IWebElement BtnBack => this.driver.FindElement(By.XPath("//button[@id='back-to-products']"));
        //TC06
        //ItemRandom
        private IWebElement LnkItemOnsie => this.driver.FindElement(By.XPath("//a[@id='item_2_title_link']"));
        
        private IWebElement ImgItemOnsie => this.driver.FindElement(By.XPath("//div[@class='inventory_details_name large_size']"));
       
        //Item Not found
        private IWebElement LnkItemNotFound => this.driver.FindElement(By.XPath("//a[@id='item_5_title_link']"));

       
        private IWebElement ImgItemNotFound => this.driver.FindElement(By.XPath("//img[@alt='ITEM NOT FOUND']"));
        
        private IWebElement ImgItemNotFound_Assert => this.driver.FindElement(By.XPath("//img[@alt='Sauce Labs Fleece Jacket']"));
        #endregion

        #region Page Actions
        public ItemPage ChooseRandomItem()
        {          
            Thread.Sleep(1000);
            LnkItem.Click();
                    
            return new ItemPage(this.driver);
        }
        #region TC06
        //ItemRandom Method
        public void chooseItemOnsie()
        {
            Thread.Sleep(2000);
            LnkItemOnsie.Click();
        }
        //Check if Item swap Image
        public bool IsImageONsieDisplayed()
        {
            try
            {
                return this.ImgItemOnsie.Displayed;
                Thread.Sleep(2000);
            }
            catch
            {
                return false;
            }
        }
        public void BacktoProducts()
        {
            
            Thread.Sleep(2000);
            BtnBack.Click();
        }

        public void ChooseItemNotFound()
        {
           
            Thread.Sleep(2000);
            LnkItemNotFound.Click();
        }

        public bool IsImageNotFoundDisplayed()
        {
            try
            {
                return this.ImgItemNotFound.Displayed;
                Thread.Sleep(2000);
            }
            catch
            {
                return false;
            }
        }
        public void BacktoProductsAgain()
        {
         
            Thread.Sleep(5000);
            BtnBack.Click();
        }
        public bool AssertIsImageNotFoundDisplayed()
        {
            try
            {
                return this.ImgItemNotFound_Assert.Displayed;
                Thread.Sleep(2000);
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #endregion
    }
}

﻿using AutomationAssignment_DuyHC1.Base;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class CartPage : BasePage
    {
        public CartPage(IWebDriver driver) : base(driver)
        {

           
        }

        #region Page Elements
        private IWebElement BtnAddToCart => this.driver.FindElement(By.XPath("//button[@id='checkout']"));
        private IWebElement BtnCancel => this.driver.FindElement(By.XPath("//button[@id='cancel']"));
        
        #endregion


        #region Page Actions
        public CheckoutPage ClickonButtonCheckOut()
        {
            Thread.Sleep(1000);
            BtnAddToCart.Click();

            return new CheckoutPage(this.driver);
        }

        //TC03 Check if Button Cancel is Display
        public bool IsButtonCancelDisplayed()
        {
            try
            {
                return this.BtnCancel.Displayed;
            }
            catch
            {
                return false;
            }
        }
        #endregion
    }
}

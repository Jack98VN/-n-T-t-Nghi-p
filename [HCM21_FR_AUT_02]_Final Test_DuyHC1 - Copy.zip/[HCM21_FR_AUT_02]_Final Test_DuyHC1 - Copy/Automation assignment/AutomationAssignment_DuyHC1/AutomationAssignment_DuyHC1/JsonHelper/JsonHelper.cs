﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace AutomationAssignment_DuyHC1.JsonHelper
{
    class JsonHelper
    {
        public static IEnumerable<object[]> GetDataFromJsonFile(string path)
        {
            #region JsonHelper
            StreamReader file = File.OpenText(path);
            JsonTextReader reader = new JsonTextReader(file);
            JObject jsonData = (JObject)JToken.ReadFrom(reader);

            JArray jsonArray = (JArray)jsonData["Data"];
            IList<DataJson> dtjson = jsonArray.ToObject<IList<DataJson>>();

            foreach (var data in dtjson)
            {
                var tourInfo = new Dictionary<string, string>();
                tourInfo.Add("Username", data.Username.ToString());
                tourInfo.Add("Password", data.Password.ToString());
                tourInfo.Add("Firstname", data.Firstname.ToString());
                tourInfo.Add("Lastname", data.Lastname.ToString());
                tourInfo.Add("Zipcode", data.Zipcode.ToString());        
               

                yield return new object[]
                {
                    tourInfo
                };
            }
            file.Close();
            #endregion
        }
    }
}

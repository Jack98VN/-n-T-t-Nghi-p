﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationAssignment_DuyHC1.JsonHelper
{
    class AddData_ReadFromJson
    {

        public static IEnumerable<object[]> AddData => JsonHelper.GetDataFromJsonFile(@"C:\Users\Duy\Desktop\[HCM21_FR_AUT_02]_Final Test_DuyHC1\Automation assignment\AutomationAssignment_DuyHC1\AutomationAssignment_DuyHC1\JsonHelper\Data.json");

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationAssignment_DuyHC1.ExcelHelper
{
    public class ExcelDataTest
    {
        public static IEnumerable<object[]> TestValue => ExcelHelper.ReadDataFromExcel(@"C:\Users\Duy\Desktop\[HCM21_FR_AUT_02]_Final Test_DuyHC1\Automation assignment\AutomationAssignment_DuyHC1\AutomationAssignment_DuyHC1\ExcelHelper\datatest.xlsx", "Sheet1");
    }
}

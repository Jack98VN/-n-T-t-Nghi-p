﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace AutomationAssignment_DuyHC1.ExcelHelper
{
    public class ExcelHelper
    {
        public static IEnumerable<object[]> ReadDataFromExcel(string path, string sheet)
        {

            IWorkbook workBook = null;
            FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
            if (path.IndexOf(".xlsx") > 0)
            {
                workBook = new XSSFWorkbook(fileStream);
            }
            else if (path.IndexOf(".xls") > 0)
            {
                workBook = new HSSFWorkbook(fileStream);
            }

            ISheet datasheet = workBook.GetSheet(sheet);

            int startRow = 1;
            int startCol = 0;
            int totalRows = datasheet.LastRowNum;
            int totalCols = datasheet.GetRow(0).LastCellNum;

            var row = 1;
            for (int i = startRow; i <= totalRows; i++, row++)
            {
                var testParams = new Dictionary<string, string>();
                var column = 0;
                for (int j = startCol; j < totalCols; j++, column++)
                {
                    // Check if data type in cell can be formated to string or not
                    if (datasheet.GetRow(0).GetCell(column).CellType != CellType.String)
                    {
                        throw new InvalidOperationException(string.Format("Cell with name of parameter must be string only, file {0} at sheet {1} row {2} column {3}", path, sheet, 0, column));
                    }

                    var cellType = datasheet.GetRow(row).GetCell(column).CellType;
                    switch (cellType)
                    {
                        case CellType.String:
                            testParams.Add(datasheet.GetRow(0).GetCell(column).StringCellValue, datasheet.GetRow(row).GetCell(column).StringCellValue);
                            break;
                        case CellType.Numeric:
                            testParams.Add(datasheet.GetRow(0).GetCell(column).StringCellValue, datasheet.GetRow(row).GetCell(column).NumericCellValue.ToString(CultureInfo.CurrentCulture));
                            break;
                        default:
                            throw new InvalidOperationException(string.Format("Not supported cell type {0} in file {1} at sheet {2} row {3} column {4}", cellType, path, sheet, row, column));
                    }
                }

                yield return new object[] {
                    testParams
                };
            }
            fileStream.Close();
        }
    }
}


﻿using AutomationAssignment_DuyHC1.ExcelHelper;
using AutomationAssignment_DuyHC1.JsonHelper;
using AutomationAssignment_DuyHC1.PageObjects;
using CORE.Core;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Xunit;

namespace AutomationAssignment_DuyHC1.PageTest
{

    public class Test: IDisposable
    {
        IWebDriver driver;
        private string url = "https://www.saucedemo.com/";
        #region TestFixture : IDisposable  
        public Test()
        {
            this.driver = new DriverManager().CreateDriver();
        }
        public void Dispose()
        {
            this.driver.Quit();
        }
        #endregion


        #region TC01:Verify the Payment Information, Shipping Information should be displayed no any broken.
        /// <summary>
        /// TC01:Verify the Payment Information, Shipping Information should be displayed no any broken.
        /// </summary>
        [Fact]    
        public void TC01()
        {
           
            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            //Declare string value 
            string username = "standard_user";
            string password = "secret_sauce";
            string firstname = "Huynh";
            string lastname = "Duy";
            string zipcode = "123";

            LoginPage loginPage = new LoginPage(driver);

            InventoryPage inventoryPage = loginPage.LoginToSystem(username, password);

            ItemPage itemPage = inventoryPage.ChooseRandomItem();

            CartPage cartPage = itemPage.AddItemtoCart();

            CheckoutPage checkoutPage = cartPage.ClickonButtonCheckOut();

            Checkout_Overview checkout_Overview = checkoutPage.ConfirmOrderItem(firstname, lastname, zipcode);
            Assert.True(checkout_Overview.IsLblPaymentInformationDisplayed());
            Assert.True(checkout_Overview.IsLblShippingInformationDisplayed());
            //? Assert for each case or  just one Assert

            Dispose();

        }
        #endregion


        #region TC02:Verify the Item total, Tax, Total should not string type.
        /// <summary>
        /// TC02:Verify the Item total, Tax, Total should not string type.
        /// </summary>
        [Fact]
        public void TC02()
        {
            
            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            LoginPage loginPage = new LoginPage(driver);

            InventoryPage inventoryPage = loginPage.LoginToSystem("standard_user", "secret_sauce");

            ItemPage itemPage = inventoryPage.ChooseRandomItem();

            CartPage cartPage = itemPage.AddItemtoCart();

            CheckoutPage checkoutPage = cartPage.ClickonButtonCheckOut();

            Checkout_Overview checkout_Overview = checkoutPage.ConfirmOrderItem("Huynh", "Duy", "123");
            checkout_Overview.IsLblTotalDisplayed();
            checkout_Overview.IsLblItemtotalDisplayed();
            checkout_Overview.IsLblTaxDisplayed();

            Checkout_Complete checkout_Complete = checkout_Overview.FinishOrderItem();           
           
            //Verify that Page order complete is displayed and wait for assert complete
            Assert.True(checkout_Complete.IsOrderCreatedSuccessfully());

            Dispose();
        }
        #endregion


        #region TC03: Verify Cancel, Finish button should be enabled and displayed without any broken.
        /// <summary>
        /// TC03: Verify Cancel, Finish button should be enabled and displayed without any broken.
        /// </summary>
        [Fact]
        public void TC03()
        {
           
            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            LoginPage loginPage = new LoginPage(driver);

            InventoryPage inventoryPage = loginPage.LoginToSystem("standard_user", "secret_sauce");

            ItemPage itemPage = inventoryPage.ChooseRandomItem();

            CartPage cartPage = itemPage.AddItemtoCart();
        
            CheckoutPage checkoutPage = cartPage.ClickonButtonCheckOut();

            // Verify Cancel button should be enabled and displayed without any broken.
            cartPage.IsButtonCancelDisplayed();

            Checkout_Overview checkout_Overview = checkoutPage.ConfirmOrderItem("Huynh", "Duy", "123");

            // Verify Cancel button should be enabled and displayed without any broken.
            Assert.True(checkout_Overview.IsButtonCancelDisplayed());

            // Verify Finish button should be enabled and displayed without any broken.
            Assert.True(checkout_Overview.IsButtonFinishDisplayed()); 
            
            Dispose();
        }
        #endregion


        #region TC04: Verify DESCRIPTION of product should matched as the description on inventory page  
        /// <summary>
        /// TC04: Verify DESCRIPTION of product should matched as the description on inventory page
        /// </summary>
        [Fact]
        public void TC04()
        {        
            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            LoginPage loginPage = new LoginPage(driver);

            InventoryPage inventoryPage = loginPage.LoginToSystem("standard_user", "secret_sauce");

            ItemPage itemPage = inventoryPage.ChooseRandomItem();

            //Check Description is displayed on this Page
            itemPage.IsDescriptionIsDisplayed();

            CartPage cartPage = itemPage.AddItemtoCart();

            CheckoutPage checkoutPage = cartPage.ClickonButtonCheckOut();

            Checkout_Overview checkout_Overview = checkoutPage.ConfirmOrderItem("Huynh", "Duy", "123");
            // Verify that Check Description is displayed on this Page and match with content of  
            checkout_Overview.IsDescriptionIsDisplayedAgain();

                       
            Dispose();
        }
        #endregion


        #region TC05: Negative case login (using locked_out_user)
        /// <summary>
        /// TC05: Negative case login (using locked_out_user)
        /// </summary>
        [Fact]
        public void TC05()
        {            
            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            LoginPage loginPage = new LoginPage(driver);  
            
            InventoryPage inventoryPage = loginPage.LoginToSystem("locked_out_user", "secret_sauce");

            //Check if Error Message is displayed or not displayed           
            Assert.True(loginPage.IsErrorDisplayed());

            Dispose();
        }
        #endregion


        #region TC06 : Display or not image
        /// <summary>
        /// TC06 : Display or not image
        /// </summary>
        [Fact]
        public void TC06()
        {
            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            string username = "problem_user";
            string password = "secret_sauce";

            LoginPage loginPage = new LoginPage(driver);

            InventoryPage inventoryPage = loginPage.LoginToSystem(username, password);
            //Check if Item have Image or not 
            inventoryPage.chooseItemOnsie();
            inventoryPage.IsImageONsieDisplayed();
            inventoryPage.BacktoProducts();           
            //Continue to check Image with next Item
            inventoryPage.ChooseItemNotFound();
            inventoryPage.IsImageNotFoundDisplayed();
            inventoryPage.BacktoProductsAgain();

            Assert.True(inventoryPage.AssertIsImageNotFoundDisplayed());  
            
            Dispose();
        }
        #endregion


        //Extent  Read file Excel and Json
        #region End to End Read file with Json
        [Xunit.Theory]
        [MemberData(nameof(AddData_ReadFromJson.AddData), MemberType = typeof(AddData_ReadFromJson))]
        public void TCJson(IDictionary datajson)
        {

            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
       
            LoginPage loginPage = new LoginPage(driver);

            InventoryPage inventoryPage = loginPage.LoginToSystem(datajson["Username"].ToString(), datajson["Password"].ToString());

            ItemPage itemPage = inventoryPage.ChooseRandomItem();

            CartPage cartPage = itemPage.AddItemtoCart();

            CheckoutPage checkoutPage = cartPage.ClickonButtonCheckOut();

            Checkout_Overview checkout_Overview = checkoutPage.ConfirmOrderItem(datajson["Firstname"].ToString(), datajson["Lastname"].ToString(), datajson["Zipcode"].ToString());

            Checkout_Complete checkout_Complete = checkout_Overview.FinishOrderItem();
            checkout_Complete.IsOrderCreatedSuccessfully();

            Assert.True(checkout_Complete.IsOrderCreatedSuccessfully());

            Dispose();

        }
        #endregion


        //Extent  Read file Json
        #region End to End Read file with Excel
        [Xunit.Theory]
        [MemberData(nameof(ExcelDataTest.TestValue), MemberType = typeof(ExcelDataTest))]
        public void TCExcel(IDictionary info)
        {

            driver.Navigate().GoToUrl(url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);


            //Declare string value 

            LoginPage loginPage = new LoginPage(driver);

            InventoryPage inventoryPage = loginPage.LoginToSystem(info["Username"].ToString(), info["Password"].ToString());

            ItemPage itemPage = inventoryPage.ChooseRandomItem();

            CartPage cartPage = itemPage.AddItemtoCart();

            CheckoutPage checkoutPage = cartPage.ClickonButtonCheckOut();

            Checkout_Overview checkout_Overview = checkoutPage.ConfirmOrderItem(info["Firstname"].ToString(), info["Lastname"].ToString(), info["Zipcode"].ToString());

            Checkout_Complete checkout_Complete = checkout_Overview.FinishOrderItem();
            checkout_Complete.IsOrderCreatedSuccessfully();

            Assert.True(checkout_Complete.IsOrderCreatedSuccessfully());

            Dispose();

        }
        #endregion
    
    }
}

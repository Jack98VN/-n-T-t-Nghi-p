﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationAssignment_DuyHC1.Base
{
    public class BasePage
    {

        #region Instance IWebdriver to Base Class
        //instance public IWebDriver driver
        protected IWebDriver driver;

        //Declare function
        public BasePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        #endregion
    }
}

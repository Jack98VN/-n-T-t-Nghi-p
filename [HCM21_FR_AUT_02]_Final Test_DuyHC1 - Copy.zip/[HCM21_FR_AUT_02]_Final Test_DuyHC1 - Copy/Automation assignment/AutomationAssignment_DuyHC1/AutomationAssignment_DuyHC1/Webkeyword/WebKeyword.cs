﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace AutomationAssignment_DuyHC1.PageObjects
{
    public class WebKeyword
    {
        private IWebDriver _driver { get; set; }
        public WebKeyword(IWebDriver driver)
        {
            this._driver = driver;
        }
        public IWebElement WaiteementFindingVisible(By locator, int timeout)
        {
            try
            {
                WebDriverWait waiter = new WebDriverWait(this._driver, TimeSpan.FromSeconds(timeout));
                IWebElement elementFinding = waiter.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(locator));
                return elementFinding;
            }
            catch
            {
                throw new Exception("locator type:" + locator + " can't find");
            }
        }
    }
}
